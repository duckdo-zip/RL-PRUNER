This folder contains the figures used for visualization.
